# Spillet
... slik jeg ser det er et liv.
